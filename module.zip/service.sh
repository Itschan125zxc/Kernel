#!/system/bin/sh
# Installer script (runs on module installation). This module is source-only.
# It places the placeholder files and sets permissions.
MODPATH="${0%/*}"
ui_print() { echo "$1"; }
ui_print "Fake Location (Manual) module installed. Build the native lib using Android NDK and place it at:"
ui_print "/data/adb/modules/fakelocation/zygisk/arm64-v8a/libfakelocation.so"
ui_print "Edit /data/local/tmp/fake_location.txt to change coordinates."
