# Fake Location (Manual) - Zygisk module (ready-to-build)

This package contains a **ready-to-build** Zygisk module that hooks Android Location APIs
and returns coordinates read from a plaintext file:

**/data/local/tmp/fake_location.txt**

You can edit that file (via adb or a file manager) to change your device's reported location
without rebuilding the module or reflashing.

## Default configuration
- Default coordinates in `fake_location.txt`: **40.7128,-74.0060** (New York, USA)
- Manual mode only (no auto-move)

## Contents
- `module.prop` - module metadata
- `service.sh` - installer messages
- `zygisk/arm64-v8a/libfakelocation.so` - *placeholder* (you must compile the native lib)
- `src/main.cpp` - native hooking source
- `CMakeLists.txt` - build config for Android NDK
- `build.sh` - helper to build with Android NDK (run on your PC)
- `fake_location.txt` - initial coordinates (edit this file on device)

## Build instructions (short)
1. Install Android NDK (r23b or r25 recommended).
2. On your build machine (Linux/WSL/macOS), run `./build.sh` in this folder.
3. The compiled `libfakelocation.so` will be output to `zygisk/arm64-v8a/`.
4. Zip the module or copy the folder to your device and install as normal.

Full instructions are included in README in the archive.
