\
        // main.cpp - Zygisk native source (hook skeleton)
        // Reads coordinates from /data/local/tmp/fake_location.txt (or /sdcard/fake_location.txt)
        // Returns a Location object with those coordinates when getLastKnownLocation is called.
        //
        // NOTE: This is a skeleton showing the reading and Location creation steps.
        // You need to integrate with a hook library (Dobby/AndHook/Minline) to hook methods.
        //
        // Build with Android NDK (CMake) to produce libfakelocation.so

        #include <jni.h>
        #include <string>
        #include <fstream>
        #include <sstream>
        #include <android/log.h>
        #include <time.h>

        #define LOG_TAG "FakeLocation"
        #define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
        #define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

        static double read_lat = 40.7128;
        static double read_lon = -74.0060;

        // Try read coords from file. Returns true if successful.
        static bool read_coords_from_file() {
            const char* paths[] = {"/data/local/tmp/fake_location.txt", "/sdcard/fake_location.txt", nullptr};
            for (int i=0; paths[i]!=nullptr; ++i) {
                std::ifstream ifs(paths[i]);
                if (!ifs.good()) continue;
                std::string line;
                if (!std::getline(ifs, line)) continue;
                std::istringstream ss(line);
                double lat, lon;
                char comma;
                if ( (ss >> lat) && (ss >> comma) && (ss >> lon) && (comma==',') ) {
                    read_lat = lat;
                    read_lon = lon;
                    LOGI("Read coords: %f,%f from %s", read_lat, read_lon, paths[i]);
                    return true;
                }
            }
            LOGI("Using default coords: %f,%f", read_lat, read_lon);
            return false;
        }

        // Create Android Location object given provider string
        static jobject create_location(JNIEnv* env, const char* provider) {
            jclass cls = env->FindClass("android/location/Location");
            if (cls==nullptr) {
                LOGE("Location class not found");
                return nullptr;
            }
            jmethodID ctor = env->GetMethodID(cls, "<init>", "(Ljava/lang/String;)V");
            if (ctor==nullptr) {
                LOGE("Location ctor not found");
                return nullptr;
            }
            jstring jprovider = env->NewStringUTF(provider);
            jobject loc = env->NewObject(cls, ctor, jprovider);
            env->DeleteLocalRef(jprovider);

            jmethodID setLat = env->GetMethodID(cls, "setLatitude", "(D)V");
            jmethodID setLon = env->GetMethodID(cls, "setLongitude", "(D)V");
            jmethodID setAcc = env->GetMethodID(cls, "setAccuracy", "(F)V");
            jmethodID setTime = env->GetMethodID(cls, "setTime", "(J)V");

            env->CallVoidMethod(loc, setLat, (jdouble)read_lat);
            env->CallVoidMethod(loc, setLon, (jdouble)read_lon);
            env->CallVoidMethod(loc, setAcc, (jfloat)5.0f);
            jlong t = (jlong)time(nullptr) * 1000LL;
            env->CallVoidMethod(loc, setTime, t);

            return loc;
        }

        // Example hooked function signature: public Location getLastKnownLocation(String provider)
        // Your hook should call read_coords_from_file() before returning the Location.
        extern "C" JNIEXPORT jobject JNICALL
        Java_com_example_fakelocation_Placeholder_hookedGetLastKnownLocation(JNIEnv* env, jclass clazz, jstring provider) {
            // This is a placeholder JNI export for testing; real hooking injects into Android's LocationManager.
            read_coords_from_file();
            return create_location(env, "gps");
        }

        // Zygisk module entrypoint could be added here for auto-init if you use a hooking framework.
