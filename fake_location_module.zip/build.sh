#!/usr/bin/env bash
# Simple build helper. Requires Android NDK and cmake or ndk-build.
# Usage: ./build.sh
set -e
NDK_ROOT=${NDK_ROOT:-$ANDROID_NDK_HOME}
if [ -z "$NDK_ROOT" ]; then
  echo "Please set NDK_ROOT or ANDROID_NDK_HOME to your NDK path."
  exit 1
fi
mkdir -p build && cd build
cmake -DCMAKE_TOOLCHAIN_FILE=$NDK_ROOT/build/cmake/android.toolchain.cmake \
      -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-24 ..
cmake --build . -- -j$(nproc || 4)
# copy output
mkdir -p ../zygisk/arm64-v8a
cp libfakelocation.so ../zygisk/arm64-v8a/libfakelocation.so
echo "Build finished. libfakelocation.so is in zygisk/arm64-v8a/"
